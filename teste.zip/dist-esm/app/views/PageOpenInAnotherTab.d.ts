/// <reference types="react" />
export declare const PageOpenInAnotherTab: () => JSX.Element;
//# sourceMappingURL=PageOpenInAnotherTab.d.ts.map