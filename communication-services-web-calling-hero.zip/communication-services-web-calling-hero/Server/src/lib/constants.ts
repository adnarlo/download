// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

export const GUID_FOR_INITIAL_TOPIC_NAME = 'c774da81-94d5-4652-85c7-6ed0e8dc67e6';
