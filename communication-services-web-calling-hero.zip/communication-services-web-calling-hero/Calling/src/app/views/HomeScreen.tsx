// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

import React, { useState } from 'react';
import { Stack, PrimaryButton, Image, IChoiceGroupOption, Text, TextField } from '@fluentui/react';

import itauSVG from '../../assets/itau.svg';
import videoconferenciaSVG from '../../assets/videoconferencia.svg';

import {
  imgStyle,
  infoContainerStyle,
  callContainerStackTokens,
  configContainerStyle,
  configContainerStackTokens,
  containerStyle,
  containerTokens,
  headerStyle,
  teamsItemStyle,
  buttonStyle,

  headerItauStyle,
  imgStyleIcone
} from '../styles/HomeScreen.styles';

import { ThemeSelector } from '../theming/ThemeSelector';
import { localStorageAvailable } from '../utils/localStorage';
import { getDisplayNameFromLocalStorage, saveDisplayNameToLocalStorage } from '../utils/localStorage';
import { DisplayNameField } from './DisplayNameField';
import { TeamsMeetingLinkLocator } from '@azure/communication-calling';

export interface HomeScreenProps {
  startCallHandler(callDetails: { displayName: string; callLocator?: TeamsMeetingLinkLocator }): void;
  joiningExistingCall: boolean;
}

export const HomeScreen = (props: HomeScreenProps): JSX.Element => {
  const imagePropsItau = { src: itauSVG.toString() };
  const imagePropsTeams = { src: videoconferenciaSVG.toString() };

  const headerTitle = props.joiningExistingCall ? 'Junte-se a uma chamada' : 'Junte-se a chamada';
  //const callOptionsGroupLabel = 'Selecione uma opção de chamada';
  const buttonText = 'Próximo';
  const callOptions: IChoiceGroupOption[] = [
    { key: 'ACSCall', text: 'Inicie uma chamada' },

    { key: 'TeamsMeeting', text: 'Junte-se a uma chamada do Teams' }
  ];

  // Get display name from local storage if available
  const defaultDisplayName = localStorageAvailable ? getDisplayNameFromLocalStorage() : null;
  const [displayName, setDisplayName] = useState<string | undefined>(defaultDisplayName ?? undefined);

  const [chosenCallOption] = useState<IChoiceGroupOption>(callOptions[1]);
  const [callLocator, setCallLocator] = useState<TeamsMeetingLinkLocator>();

  const startGroupCall: boolean = chosenCallOption.key === 'ACSCall';
  const teamsCallChosen: boolean = chosenCallOption.key === 'TeamsMeeting';

  const buttonEnabled = displayName && (startGroupCall || (teamsCallChosen && callLocator));

  return (
    <Stack
      horizontal
      wrap
      horizontalAlign="center"
      verticalAlign="center"
      tokens={containerTokens}
      className={containerStyle}
    >
      <div className={headerItauStyle}>
        <img alt="Welcome to the ACS Calling sample app" className={imgStyleIcone} {...imagePropsItau} />
        <h1>Vídeo Atendimento</h1>
      </div>

      <Image alt="Welcome to the ACS Calling sample app" className={imgStyle} {...imagePropsTeams} />
      <Stack className={infoContainerStyle}>
        <Text role={'heading'} aria-level={1} className={headerStyle}>
          {headerTitle}
        </Text>
        <Stack className={configContainerStyle} tokens={configContainerStackTokens}>
          <Stack tokens={callContainerStackTokens}>
            {teamsCallChosen && (
              <TextField
                className={teamsItemStyle}
                iconProps={{ iconName: 'Link' }}
                placeholder={'Insira um link Teams para a chamada'}
                onChange={(_, newValue) => newValue && setCallLocator({ meetingLink: newValue })}
              />
            )}
          </Stack>
          <DisplayNameField defaultName={displayName} setName={setDisplayName} />
          <PrimaryButton
            disabled={!buttonEnabled}
            className={buttonStyle}
            text={buttonText}
            onClick={() => {
              if (displayName) {
                saveDisplayNameToLocalStorage(displayName);

                props.startCallHandler({
                  displayName,
                  callLocator
                });
              }
            }}
          />

          <div>
            <ThemeSelector label="Tema" horizontal={true} />
          </div>
        </Stack>
      </Stack>
    </Stack>
  );
};
