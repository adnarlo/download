const commonConfig = require('./.common.babelrc.js');

module.exports = {
  ...commonConfig
};
